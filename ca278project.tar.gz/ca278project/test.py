#!/usr/bin/env python

import codes #imports codes.py which provides the universal currency code and welcome

import countries2 #imports countries2.py which provides the option to viewing what countries use what currency

import currency #imports currency whcih shows the currency converter